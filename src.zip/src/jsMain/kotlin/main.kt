import kotlinx.browser.document
import kotlinx.browser.window
import org.w3c.dom.HTMLDivElement
import org.w3c.dom.HTMLElement
import xim.poc.MainTool
import xim.poc.browser.BrowserPlatformDependencies
import xim.poc.browser.ExecutionEnvironment
import xim.poc.browser.PlatformDependencies
import xim.poc.game.GameState
import xim.poc.game.configuration.assetviewer.AssetViewer
import xim.poc.game.configuration.v0.GameV0
import xim.poc.tools.DebugToolsManager
import xim.util.OnceLogger

private var started = false
private lateinit var platform: PlatformDependencies

fun main() {
    if (isLocalHost()) {
        onStart()
    } else {
        val startButton = (document.getElementById("start-container") as HTMLElement)
        startButton.onclick = { onStart() }
    }
}

fun onStart() {
    if (started) { return }
    started = true

    val startContainer = document.getElementById("start-container") as HTMLDivElement
    startContainer.remove()

    platform = BrowserPlatformDependencies.get(canvasId = "canvas") ?: return

    val gameMode = when (ExecutionEnvironment.getExecutionParameter("mode")) {
        "game" -> GameV0
        else -> AssetViewer
    }
    GameState.setGameMode(gameMode)

    if (isLocalHost() || gameMode.configuration.debugControlsEnabled) {
        OnceLogger.enabled = true
        DebugToolsManager.debugEnabled = true
        DebugToolsManager.showDebugOnlyTools()
    }

    if (isLocalHost()) {
        DebugToolsManager.showLocalHostTools()
    }

    MainTool.run(platform)
}

fun isLocalHost(): Boolean {
    return window.location.hostname == "localhost"
}