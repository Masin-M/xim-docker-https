package xim.poc.browser;

interface Window