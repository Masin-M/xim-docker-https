package xim.poc.game.configuration.constants

val rangedAttack = RangedAttackSkillId(0)
