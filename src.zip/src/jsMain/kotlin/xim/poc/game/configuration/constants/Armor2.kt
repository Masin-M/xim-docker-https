@file:Suppress("unused", "SpellCheckingInspection")

package xim.poc.game.configuration.constants

const val armorRawhideMask_26794 = 26794
const val armorPsyclothTiara_26796 = 26796
const val armorRawhideVest_26950 = 26950
const val armorPsyclothVest_26952 = 26952
const val armorKubiraMeikogai_26959 = 26959
const val armorAnnointKalasiris_26960 = 26960
const val armorMakoraMeikogai_26961 = 26961
const val armorEnforcersHarness_26962 = 26962
const val armorRawhideGloves_27100 = 27100
const val armorPsyclothManillas_27102 = 27102
const val armorRawhideTrousers_27285 = 27285
const val armorPsyclothLappas_27287 = 27287
const val armorRawhideBoots_27460 = 27460
const val armorPsyclothBoots_27462 = 27462
const val armorPenetratingCape_27605 = 27605
const val armorThaumCape_27607 = 27607
const val armorDispersersCape_27606 = 27606
const val armorSinewBelt_28417 = 28417
const val armorHuaniCollar_28384 = 28384
const val armorAtzintliNecklace_28385 = 28385
const val armorQuanpurNecklace_28387 = 28387
const val armorEschanStone_28415 = 28415
const val armorLuciditySash_28416 = 28416
const val armorSlimeEarring_28511 = 28511