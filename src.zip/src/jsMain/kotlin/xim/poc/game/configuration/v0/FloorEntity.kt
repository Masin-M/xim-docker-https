package xim.poc.game.configuration.v0

interface FloorEntity {

    fun update(elapsedFrames: Float)

    fun cleanup()

}