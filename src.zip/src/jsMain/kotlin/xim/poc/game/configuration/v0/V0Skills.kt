package xim.poc.game.configuration.v0

