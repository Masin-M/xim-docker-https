package xim.poc.game.configuration.v0.constants

import xim.poc.game.configuration.NpcBehaviorId

val npcVrednev = NpcBehaviorId(1)
