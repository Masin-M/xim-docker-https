package xim.poc.game.configuration.v0.tower

class TowerState {

    var currentFloor = 0

}