package xim.poc.gl;

class ScreenSettingsSupplier(
        var width: Int = 0,
        var height: Int = 0,
        var aspectRatio: Float = 0.0f,
)