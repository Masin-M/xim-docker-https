package xim.poc.gl;

import web.gl.WebGLShader

data class GLShader(var shaderId: WebGLShader)
